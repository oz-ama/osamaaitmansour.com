import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Poppins, Geist_Mono, Noto_Kufi_Arabic } from 'next/font/google'
import { BackToTop } from '@/components/back-to-top'
import { WelcomePopup } from '@/components/welcome-popup'
import './globals.css'

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800', '900'],
  variable: '--font-poppins',
})

const geistMono = Geist_Mono({
  subsets: ['latin'],
  variable: '--font-geist-mono',
})

const arabic = Noto_Kufi_Arabic({
  subsets: ['arabic'],
  weight: ['500'],
  variable: '--font-arabic',
})

export const metadata: Metadata = {
  title: {
    default: 'Osama Ait Mansour — Graphic Designer, UI/UX Designer & 3D Artist',
    template: '%s — Osama Ait Mansour',
  },
  description:
    'Portfolio and résumé of Osama Ait Mansour, a multidisciplinary graphic designer, UI/UX designer and 3D artist from Morocco. Brand identities, web experiences, photoreal 3D renders and campaigns.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#d6d2c6',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${poppins.variable} ${geistMono.variable} ${arabic.variable}`}>
      <body className="antialiased">
        {children}
        <BackToTop />
        <WelcomePopup />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
