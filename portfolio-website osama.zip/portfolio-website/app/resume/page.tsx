import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowDownToLine, ArrowLeft, ArrowUpRight, Mail, MapPin, Phone } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { ContactFooter } from '@/components/contact-footer'
import { RollText } from '@/components/roll-text'

export const metadata: Metadata = {
  title: 'Résumé',
  description: 'Professional résumé of Osama Ait Mansour — Graphic Designer, UI/UX Designer and 3D Artist.',
}

const experience = [
  {
    period: 'MAR 2026 — PRESENT',
    company: 'TECNIBO MOROCCO',
    role: 'Graphic Designer · 3D Artist · UI/UX Designer',
    details: ['Brand identity and visual communication', '3D product visualization and renders', 'Website UI/UX and digital catalogue design'],
  },
  {
    period: '2025 — 2026',
    company: 'FRESHZILLA · FREELANCE',
    role: 'Graphic Designer · 3D Visualizer',
    details: ['Commercial catalogues and product sheets', 'Flyers, promotional assets and digital marketing', 'Website design and updates'],
  },
  {
    period: '2025 — 2026',
    company: 'MATELMED · FREELANCE',
    role: 'Graphic Designer',
    details: ['Furniture and product 3D renders', 'Advertising posters and promotional visuals', 'Social media content and brand communication'],
  },
  {
    period: 'AUG 2024 — 2025',
    company: 'NEW DETROIT GROUP · MOMENTO DESSERTS',
    role: 'Graphic Designer · 3D Artist · UI/UX Designer',
    details: ['Commercial presentations, brochures and catalogues', 'Photorealistic 3D renders and product visuals', 'Brand identity, social media campaigns and website UI/UX'],
  },
  {
    period: '2022 — 2024',
    company: 'ARDEVUR · SKETCHDHOP · ZEPHYR DÉVELOPPEMENT',
    role: 'Graphic Designer · 3D Artist · Webmaster',
    details: ['Visual communication and marketing assets', 'Web and mobile interface design', 'Website management and 3D visual production'],
  },
]

const skills = [
  { title: 'Design & Art Direction', items: 'Graphic design, branding, visual identity, print, editorial, social media, marketing visuals' },
  { title: 'UI/UX & Web', items: 'UI design, UX design, wireframing, prototyping, web design, WordPress, Elementor, WooCommerce' },
  { title: '3D & Visualization', items: '3D modeling, product visualization, architectural visualization, photorealistic rendering, 3D animation' },
  { title: 'Creative AI', items: 'AI-assisted visual creation, concept development, creative workflow optimization' },
]

export default function ResumePage() {
  return (
    <>
      <SiteHeader />
      <main className="resume-page overflow-hidden">
        <section className="mx-auto max-w-7xl px-5 pb-16 pt-8 md:px-10 md:pb-24 md:pt-12">
          <div className="resume-enter flex flex-wrap items-center justify-between gap-4">
            <Link href="/" className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground px-4 py-2 text-sm font-medium">
              <ArrowLeft className="size-4 transition-transform duration-500 group-hover:-translate-x-1" aria-hidden="true" />
              Back to portfolio
            </Link>
            <a href="/osama-ait-mansour-cv.pdf" download="Osama-Ait-Mansour-CV.pdf" className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-4 py-2 text-sm font-semibold text-background [--btn-fill:var(--accent)] [--btn-fill-foreground:var(--foreground)]">
              <ArrowDownToLine className="btn-icon size-4" aria-hidden="true" /> Download PDF
            </a>
          </div>

          <div className="resume-enter mt-14 border-b border-foreground pb-8 md:mt-20 md:pb-12" style={{ animationDelay: '90ms' }}>
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">Curriculum vitae · 2026</p>
            <h1 className="mt-5 pt-[0.3em] text-[16vw] font-black uppercase leading-[0.78] tracking-[-0.085em] md:text-[10rem] [--roll-stagger:25ms]">
              <RollText text="Résumé" />
            </h1>
            <div className="mt-8 flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <h2 className="text-2xl font-bold uppercase tracking-tight md:text-4xl">Osama Ait Mansour</h2>
                <p className="mt-2 text-sm font-medium md:text-base">Graphic Designer <span className="text-accent">·</span> UI/UX Designer <span className="text-accent">·</span> 3D Artist</p>
              </div>
              <div className="grid gap-2 text-sm text-muted-foreground">
                <a className="inline-flex items-center gap-2 transition-colors hover:text-foreground" href="mailto:osamaaitmansour@gmail.com"><Mail className="size-4" /> osamaaitmansour@gmail.com</a>
                <a className="inline-flex items-center gap-2 transition-colors hover:text-foreground" href="tel:+212636968410"><Phone className="size-4" /> +212 6 36 96 84 10</a>
                <span className="inline-flex items-center gap-2"><MapPin className="size-4" /> Morocco</span>
              </div>
            </div>
          </div>

          <div className="resume-enter grid gap-10 border-b border-foreground py-10 md:grid-cols-12 md:gap-12 md:py-14" style={{ animationDelay: '170ms' }}>
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground md:col-span-3">Profile / 01</h2>
            <p className="text-pretty text-lg leading-relaxed md:col-span-9 md:text-2xl md:leading-relaxed">Multidisciplinary designer with 5+ years of experience across graphic design, UI/UX, 3D visualization and digital communication. Focused on visual identities, catalogues, marketing assets, photorealistic renders and web experiences across furniture, interiors, food, retail and digital products.</p>
          </div>

          <section className="resume-enter border-b border-foreground py-10 md:py-14" style={{ animationDelay: '240ms' }}>
            <div className="mb-8 grid gap-3 md:grid-cols-12 md:gap-12">
              <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground md:col-span-3">Experience / 02</h2>
              <p className="text-sm text-muted-foreground md:col-span-9">Selected professional experience</p>
            </div>
            <div className="md:ml-[25%]">
              {experience.map((job, index) => (
                <article key={job.company} className="resume-job group grid gap-3 border-t border-foreground/20 py-6 md:grid-cols-[150px_1fr] md:gap-8 md:py-8" style={{ animationDelay: `${index * 75}ms` }}>
                  <p className="font-mono text-[10px] tracking-[0.14em] text-muted-foreground md:pt-1">{job.period}</p>
                  <div>
                    <h3 className="text-xl font-extrabold uppercase tracking-tight transition-colors group-hover:text-accent md:text-2xl">{job.company}</h3>
                    <p className="mt-1 text-sm font-medium">{job.role}</p>
                    <ul className="mt-4 grid gap-2 text-sm leading-relaxed text-muted-foreground">
                      {job.details.map((detail) => <li key={detail} className="flex gap-3"><span className="text-accent">↗</span><span>{detail}</span></li>)}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="resume-enter grid gap-10 border-b border-foreground py-10 md:grid-cols-12 md:gap-12 md:py-14" style={{ animationDelay: '320ms' }}>
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground md:col-span-3">Capabilities / 03</h2>
            <div className="grid gap-7 md:col-span-9 md:grid-cols-2 md:gap-x-10">
              {skills.map((skill, i) => (
                <div key={skill.title} className="border-t border-foreground/20 pt-4">
                  <p className="font-mono text-xs text-accent">0{i + 1}</p>
                  <h3 className="mt-2 text-lg font-bold uppercase tracking-tight">{skill.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{skill.items}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="resume-enter grid gap-10 border-b border-foreground py-10 md:grid-cols-12 md:gap-12 md:py-14" style={{ animationDelay: '390ms' }}>
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground md:col-span-3">Education / 04</h2>
            <div className="grid gap-6 md:col-span-9 md:grid-cols-2">
              <div className="border-t border-foreground/20 pt-4"><p className="font-mono text-xs text-muted-foreground">2018 — 2023</p><h3 className="mt-2 font-bold uppercase">Licence en Design</h3><p className="mt-1 text-sm text-muted-foreground">Institut National des Beaux-Arts de Tétouan (INBA)</p></div>
              <div className="border-t border-foreground/20 pt-4"><p className="font-mono text-xs text-muted-foreground">2017 — 2018</p><h3 className="mt-2 font-bold uppercase">Année préparatoire · Arts & Design</h3><p className="mt-1 text-sm text-muted-foreground">École Supérieure des Beaux-Arts de Casablanca</p></div>
              <div className="border-t border-foreground/20 pt-4"><p className="font-mono text-xs text-muted-foreground">2017 — 2018 · as listed in CV</p><h3 className="mt-2 font-bold uppercase">Baccalauréat Arts Appliqués</h3><p className="mt-1 text-sm text-muted-foreground">Lycée Youssef Ben Tachefine, Agadir</p></div>
            </div>
          </section>

          <section className="resume-enter grid gap-10 py-10 md:grid-cols-12 md:gap-12 md:py-14" style={{ animationDelay: '450ms' }}>
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground md:col-span-3">Tools & languages / 05</h2>
            <div className="grid gap-8 md:col-span-9 md:grid-cols-2">
              <div><h3 className="font-bold uppercase">Software</h3><p className="mt-3 text-sm leading-7 text-muted-foreground">Photoshop · Illustrator · InDesign · After Effects · Lightroom · Figma · Adobe XD · 3ds Max · Blender · ZBrush · Unreal Engine · Spline · Twinmotion · WordPress · Elementor · WooCommerce · Microsoft Office</p></div>
              <div><h3 className="font-bold uppercase">Languages</h3><ul className="mt-3 grid gap-3 text-sm"><li className="flex justify-between border-b border-foreground/15 pb-2"><span>Arabic</span><span className="text-muted-foreground">Native</span></li><li className="flex justify-between border-b border-foreground/15 pb-2"><span>French</span><span className="text-muted-foreground">Fluent</span></li><li className="flex justify-between border-b border-foreground/15 pb-2"><span>English</span><span className="text-muted-foreground">Professional</span></li></ul></div>
            </div>
          </section>

          <div className="resume-enter flex flex-col items-start justify-between gap-6 border-t border-foreground pt-8 md:flex-row md:items-center" style={{ animationDelay: '510ms' }}>
            <div><p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Have a project or opportunity?</p><p className="mt-2 text-2xl font-black uppercase tracking-tight md:text-4xl">Let’s make something matter.</p></div>
            <Link href="/#contact" className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground px-5 py-3 text-sm font-semibold">Get in touch <ArrowUpRight className="btn-icon size-4" /></Link>
          </div>
        </section>
      </main>
      <ContactFooter />
    </>
  )
}
