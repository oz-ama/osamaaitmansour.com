import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { DisciplineMarquee } from '@/components/discipline-marquee'
import { WorkGrid } from '@/components/work-grid'
import { About } from '@/components/about'
import { ContactFooter } from '@/components/contact-footer'

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <DisciplineMarquee />
        <WorkGrid />
        <About />
      </main>
      <ContactFooter />
    </>
  )
}
