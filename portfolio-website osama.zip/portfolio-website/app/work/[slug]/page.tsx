import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { ContactFooter } from '@/components/contact-footer'
import { RollText } from '@/components/roll-text'
import { getProject, projects } from '@/lib/projects'
import { cn } from '@/lib/utils'

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: PageProps<'/work/[slug]'>): Promise<Metadata> {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) return {}
  return {
    title: project.title,
    description: project.summary,
    openGraph: { images: [`/work/${project.slug}-cover.webp`] },
  }
}

export default async function ProjectPage({ params }: PageProps<'/work/[slug]'>) {
  const { slug } = await params
  const project = getProject(slug)
  if (!project) notFound()

  const index = projects.indexOf(project)
  const next = projects[(index + 1) % projects.length]
  const dark = project.tone === 'dark'

  return (
    <>
      <SiteHeader />
      <main>
        <article>
          <header className="mx-auto max-w-7xl px-5 pb-14 pt-10 md:px-10 md:pb-20 md:pt-14">
            <Link
              href="/#work"
              className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground px-4 py-2 text-sm font-medium"
            >
              <ArrowLeft className="btn-icon-x size-4 transition-transform duration-500" aria-hidden="true" />
              <RollText text="All projects" />
            </Link>
            <p className="mt-10 font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Project {String(index + 1).padStart(2, '0')} / {String(projects.length).padStart(2, '0')}
            </p>
            <h1 className="mt-2 cursor-default text-balance text-6xl font-black uppercase leading-[0.85] tracking-tighter md:text-9xl [--roll-stagger:30ms]">
              <RollText text={project.title} />
            </h1>

            <div className="mt-12 grid gap-10 border-t border-foreground pt-8 lg:grid-cols-12">
              <dl className="grid grid-cols-2 gap-6 lg:col-span-5">
                <div>
                  <dt className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Client</dt>
                  <dd className="mt-1 font-semibold">{project.client}</dd>
                </div>
                <div>
                  <dt className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Category</dt>
                  <dd className="mt-1 font-semibold">{project.categories.join(', ')}</dd>
                </div>
                <div className="col-span-2">
                  <dt className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Disciplines</dt>
                  <dd className="mt-2">
                    <ul className="flex flex-wrap gap-2">
                      {project.disciplines.map((d) => (
                        <li key={d} className="rounded-full border border-foreground px-3 py-1 text-sm font-medium">
                          {d}
                        </li>
                      ))}
                    </ul>
                  </dd>
                </div>
              </dl>
              <p className="text-pretty leading-relaxed lg:col-span-7 md:text-lg">{project.description}</p>
            </div>
          </header>

          <div className={cn('py-6 md:py-10', dark ? 'bg-ink' : 'bg-card')}>
            <div className="mx-auto max-w-5xl">
              {project.slices.map((height, i) => (
                <Image
                  key={i}
                  src={`/work/${project.slug}-${String(i + 1).padStart(2, '0')}.webp`}
                  alt={i === 0 ? `${project.title} presentation board` : ''}
                  width={1400}
                  height={height}
                  sizes="(min-width: 1024px) 1024px, 100vw"
                  className="block h-auto w-full"
                  priority={i === 0}
                />
              ))}
            </div>
          </div>
        </article>

        <nav aria-label="Next project" className="border-b border-border">
          <Link href={`/work/${next.slug}`} className="roll-trigger group mx-auto block max-w-7xl px-5 py-16 md:px-10 md:py-24">
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Next project</span>
            <span className="mt-2 flex items-center justify-between gap-6">
              <span className="text-5xl font-black uppercase tracking-tighter md:text-8xl [--roll-stagger:30ms]">
                <RollText text={next.title} />
              </span>
              <ArrowRight
                className="size-10 shrink-0 transition-all duration-500 ease-[var(--ease-out-expo)] group-hover:translate-x-4 group-hover:text-accent md:size-16"
                aria-hidden="true"
              />
            </span>
          </Link>
        </nav>
      </main>
      <ContactFooter />
    </>
  )
}
