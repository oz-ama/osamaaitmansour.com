export type Category = 'UI/UX' | 'Branding' | '3D' | 'Social Media' | 'Print'

export type Project = {
  slug: string
  title: string
  client: string
  summary: string
  description: string
  categories: Category[]
  disciplines: string[]
  tone: 'light' | 'dark'
  slices: number[]
}

export const categories: Category[] = ['UI/UX', 'Branding', '3D', 'Social Media', 'Print']

export const projects: Project[] = [
  {
    slug: 'ardevur',
    title: 'Ardevur',
    client: 'Hashtag64',
    summary: 'Campaign design and 3D assets for a resource-strategy board game.',
    description:
      'At Hashtag64, I work as a 3D designer on Ardevur, a resource-strategy game currently in development. My role focuses on creating high-quality 3D elements and visual assets that shape the game’s environment, style, and player experience — from box design and component renders to the rulebook, the Total Control mystery book and the crowdfunding campaign.',
    categories: ['3D', 'Print', 'Social Media'],
    disciplines: ['Campaign Design', '3D Rendering', 'Packaging', 'Rulebook', 'Social Media'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 1800, 1800, 1523, 1800, 1800, 1800, 1800, 1267, 1800, 1800, 1800, 1800, 1800, 1800, 681, 1800, 1800, 1345],
  },
  {
    slug: 'soul',
    title: 'Soul',
    client: 'Forge of Worlds',
    summary: 'An immersive online gaming platform with sculpted 3D characters.',
    description:
      '“Soul: Forge of Worlds” is an immersive online gaming platform that transcends boundaries and sparks the imagination. I designed the full UI/UX — home, landing, about and trailer pages — and sculpted the 3D characters that define the world’s dark-fantasy visual language.',
    categories: ['UI/UX', '3D'],
    disciplines: ['UI/UX', '3D Character', 'Web Design', 'Art Direction'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 1800, 1800, 1800, 1105],
  },
  {
    slug: 'cuisine-sur-mesure',
    title: 'Cuisine Sur Mesure',
    client: 'E-commerce kitchens platform',
    summary: 'A modern e-commerce platform for custom-made kitchens.',
    description:
      'Designed a modern e-commerce platform for custom kitchens, combining elegant visual design, intuitive navigation, and an immersive product experience. The project focuses on showcasing kitchen collections, exploring materials and finishes, and simplifying the journey from inspiration to personalized kitchen design.',
    categories: ['UI/UX'],
    disciplines: ['UI/UX', 'E-commerce', 'Web Design'],
    tone: 'light',
    slices: [1800, 1800, 1800, 1800, 1800, 1716, 1800, 1800, 1800, 670],
  },
  {
    slug: 'colouring-space',
    title: 'Colouring Space',
    client: 'Kids educational app',
    summary: 'An interactive colouring app for kids with a charming 3D mascot.',
    description:
      'Colouring Space is an interactive and educational coloring app for kids that I designed, featuring a charming 3D mascot, diverse assets, and vibrant backgrounds. The app’s intuitive interface, wide color palette, and engaging themes stimulate creativity and enhance fine motor skills. It also incorporates educational elements and allows kids to save and share their creations.',
    categories: ['UI/UX', '3D'],
    disciplines: ['3D Character', 'UI/UX', '3D Environment', 'Mobile App'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 1303],
  },
  {
    slug: 'momento',
    title: 'Momento',
    client: 'Momento Desserts',
    summary: 'Visual identity, packaging and web for an artisanal dessert brand.',
    description:
      'At MOMENTO, I contribute as a visual designer, helping shape the brand identity of their innovative dessert and ice cream line. I create high-quality visuals that highlight the artisanal spirit of the products and reflect the brand’s signature message, “The secret is in the creme.” My work supports packaging, marketing content, website and product presentations.',
    categories: ['Branding', 'UI/UX', 'Social Media', 'Print'],
    disciplines: ['Brand Identity', 'Packaging', 'Web Design', 'Social Media', 'Outdoor'],
    tone: 'light',
    slices: [1800, 1800, 1800, 1800, 1800, 1800, 1800, 1800, 1405, 1800, 687],
  },
  {
    slug: 'clay-ma',
    title: 'Clay.ma',
    client: 'Handmade ceramics studio',
    summary: 'Brand identity, website and packaging for a ceramics studio.',
    description:
      'Clay.ma is a handmade ceramics studio where one-of-a-kind products are created, full of positive emotions and a sense of uniqueness. Every piece differs from the next despite similar features — giving a sense of exclusivity, intimacy and authenticity. Elements of the logo were drawn from sketches of art pieces handmade by Clay.ma.',
    categories: ['Branding', 'UI/UX', 'Social Media'],
    disciplines: ['Logo', 'Colors & Type', 'Website', 'Social Media', 'Packaging'],
    tone: 'light',
    slices: [1800, 1800, 1800, 1800, 1800, 1800, 1800, 469],
  },
  {
    slug: 'new-detroit',
    title: 'New Detroit',
    client: 'Cuisine · Dressing · Placards',
    summary: 'Print, vehicle wraps and website for a custom kitchen brand.',
    description:
      'Designed a modern e-commerce platform for New Detroit, specializing in custom kitchens, dressing rooms, and wardrobes. The project combines intuitive UI/UX design, elegant visuals, and immersive product presentations — alongside in-store print, signage and vehicle branding — to deliver a seamless, premium experience.',
    categories: ['UI/UX', 'Print'],
    disciplines: ['Website', 'Print Design', 'Signage', 'Vehicle Wrap'],
    tone: 'light',
    slices: [1800, 1800, 1752, 1800, 1800, 1800, 1038],
  },
  {
    slug: 'matelmed',
    title: 'Matelmed',
    client: 'Furniture & interiors',
    summary: 'Social media content for a premium furniture brand.',
    description:
      'A social media system for Matelmed showcasing sofas, dining rooms, lighting and solid wood furniture. Photoreal product visuals and an elegant editorial layout give every post a premium, consistent feel across the feed.',
    categories: ['Social Media', '3D'],
    disciplines: ['Social Media', 'Art Direction', 'Product Visuals'],
    tone: 'light',
    slices: [1800, 1800, 1800, 277],
  },
  {
    slug: 'head-to-toes',
    title: 'Head to Toes',
    client: 'Fashion retail',
    summary: 'Charte graphique for a fashion and beauty retailer.',
    description:
      'A complete visual identity for Head to Toes — logo, color system, brand pattern and real-world applications from storefront signage to embossed materials and shopping bags.',
    categories: ['Branding'],
    disciplines: ['Logo', 'Charte Graphique', 'Pattern', 'Mockups'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 426],
  },
  {
    slug: 'oneclick',
    title: 'Oneclick',
    client: 'Creation Digital',
    summary: 'Logo and print collateral for a digital creation agency.',
    description:
      'Brand identity for Oneclick, a digital creation agency — logo exploration, color variations and printed collateral including flyers and business cards.',
    categories: ['Branding', 'Print'],
    disciplines: ['Logo', 'Flyers', 'Business Cards'],
    tone: 'dark',
    slices: [1800, 1800],
  },
  {
    slug: 'freshzilla',
    title: 'Freshzilla',
    client: 'World’s Garden',
    summary: 'Social media design for frozen fruits and fresh juices.',
    description:
      'Vibrant social media design for Freshzilla’s frozen fruit blends and juices — bold color-coded packaging visuals and promotional posts built to stand out in the feed.',
    categories: ['Social Media'],
    disciplines: ['Social Media', 'Product Visuals'],
    tone: 'light',
    slices: [1800, 1262],
  },
  {
    slug: 'worlds-garden',
    title: 'World’s Garden',
    client: 'Food service supplier',
    summary: 'A landing page for a European fresh-fruit supplier.',
    description:
      'A conversion-focused website for World’s Garden presenting five reasons restaurants choose them — 24-hour delivery, ready-to-use fruits, farm-direct pricing, natural products and 20+ years of expertise — with playful 3D-styled illustrations.',
    categories: ['UI/UX'],
    disciplines: ['Web Design', 'Landing Page'],
    tone: 'light',
    slices: [1800, 1800, 1800, 1269],
  },
  {
    slug: 'machine-corp',
    title: 'Machine Corp',
    client: 'Robotics & AI',
    summary: 'A cinematic corporate website for a robotics company.',
    description:
      'Corporate website for Machine Corp — a dark, cinematic experience covering the company’s history, mission, products, innovations and global locations.',
    categories: ['UI/UX'],
    disciplines: ['Web Design', 'UI/UX'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 1483],
  },
  {
    slug: 'great-mining',
    title: 'Great Mining',
    client: 'Mining group',
    summary: 'Corporate website for a mining and energy conglomerate.',
    description:
      'Website for Great Mining — “Mining for a better future.” A bold black-and-gold interface presenting the group’s history, operations, sustainability and locations.',
    categories: ['UI/UX'],
    disciplines: ['Web Design', 'UI/UX'],
    tone: 'dark',
    slices: [1800, 1800, 1002],
  },
  {
    slug: 'gabriel-ai',
    title: 'Gabriel AI',
    client: 'Artificial intelligence',
    summary: 'Product website for an AI platform.',
    description:
      'Product website for Gabriel AI™ explaining what the platform can do — software integration, task management and financial fulfilment — with a minimal, high-contrast dark interface.',
    categories: ['UI/UX'],
    disciplines: ['Web Design', 'UI/UX'],
    tone: 'dark',
    slices: [1800, 1800, 1022],
  },
  {
    slug: 'hashtagcoin',
    title: 'Hashtagcoin',
    client: 'Digital currency',
    summary: 'Landing page for a digital currency project.',
    description:
      'A landing page for Hashtagcoin covering features, use cases, smart contracts, partners and growth — with a deep violet palette and 3D coin renders.',
    categories: ['UI/UX', '3D'],
    disciplines: ['Web Design', '3D Rendering'],
    tone: 'dark',
    slices: [1800, 1800, 1800, 478],
  },
  {
    slug: 'great-machine-united',
    title: 'Great Machine United',
    client: 'Industrial conglomerate',
    summary: 'Corporate website for a global mega-conglomerate.',
    description:
      'Website for Great Machine United — “Our prophecy: a better future for humanity.” Presents the group’s vision, fields of impact, contribution and press releases.',
    categories: ['UI/UX'],
    disciplines: ['Web Design', 'UI/UX'],
    tone: 'light',
    slices: [1800, 1800, 1800, 603],
  },
]

export function getProject(slug: string) {
  return projects.find((p) => p.slug === slug)
}
