import Image from 'next/image'
import Link from 'next/link'
import { RollText } from '@/components/roll-text'

const nav = [
  { href: '/#work', label: 'Work' },
  { href: '/#about', label: 'About' },
  { href: '/resume', label: 'Resume' },
  { href: '/#contact', label: 'Contact' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-10">
        <Link href="/" className="flex items-center gap-3" aria-label="Osama Ait Mansour — home">
          <Image src="/ozama-logo.png" alt="" width={1073} height={1465} className="h-9 w-auto" priority />
          <span className="text-sm font-bold uppercase tracking-wide">Osama Ait Mansour</span>
        </Link>
        <nav aria-label="Primary">
          <ul className="flex items-center gap-1 text-sm font-medium md:gap-2">
            {nav.map((item) => (
              <li key={item.href} className={item.label === 'About' ? 'hidden sm:block' : undefined}>
                <Link
                  href={item.href}
                  className="btn-fx inline-block rounded-full px-3 py-2"
                >
                  <RollText text={item.label} />
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  )
}
