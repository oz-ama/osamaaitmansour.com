'use client'

import { useEffect, useState } from 'react'
import { ArrowUp } from 'lucide-react'

export function BackToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 200)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <button
      type="button"
      aria-label="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className={`btn-fx fixed bottom-5 right-5 z-[60] grid size-12 place-items-center rounded-full border border-foreground bg-foreground text-background [--btn-fill:var(--accent)] [--btn-fill-foreground:var(--foreground)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent md:bottom-8 md:right-8 ${
        visible ? 'translate-y-0 scale-100 opacity-100' : 'pointer-events-none translate-y-4 scale-90 opacity-0'
      } transition-[opacity,transform] duration-500 ease-[var(--ease-out-expo)]`}
      tabIndex={visible ? 0 : -1}
    >
      <ArrowUp className="btn-icon-up size-5" aria-hidden="true" />
    </button>
  )
}
