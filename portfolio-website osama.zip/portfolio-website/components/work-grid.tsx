'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { RollText } from '@/components/roll-text'
import { categories, projects, type Category } from '@/lib/projects'
import { cn } from '@/lib/utils'

type Filter = 'All' | Category

export function WorkGrid() {
  const [filter, setFilter] = useState<Filter>('All')
  const visible = filter === 'All' ? projects : projects.filter((p) => p.categories.includes(filter))
  const filters: Filter[] = ['All', ...categories]

  return (
    <section id="work" aria-labelledby="work-title" className="scroll-mt-16">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Selected work</p>
            <h2 id="work-title" className="mt-2 cursor-default text-5xl font-black uppercase tracking-tighter md:text-7xl">
              <RollText text="Projects" />
              <sup className="ml-2 align-top font-mono text-base font-normal tracking-normal text-muted-foreground">
                {String(visible.length).padStart(2, '0')}
              </sup>
            </h2>
          </div>
          <div role="group" aria-label="Filter projects" className="flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                aria-pressed={filter === f}
                className={cn(
                  'btn-fx rounded-full border border-foreground px-4 py-1.5 text-sm font-medium',
                  filter === f &&
                    'bg-foreground text-background [--btn-fill-foreground:var(--foreground)] [--btn-fill:var(--accent)]',
                )}
              >
                <RollText text={f} />
              </button>
            ))}
          </div>
        </div>

        <ul className="mt-12 grid gap-x-6 gap-y-12 md:grid-cols-2">
          {visible.map((project, i) => (
            <li key={project.slug}>
              <Link href={`/work/${project.slug}`} className="roll-trigger group block focus-visible:outline-none">
                <div className="relative aspect-[4/3] overflow-hidden rounded-sm bg-ink ring-offset-4 ring-offset-background group-focus-visible:ring-2 group-focus-visible:ring-foreground">
                  <Image
                    src={`/work/${project.slug}-cover.webp`}
                    alt={`${project.title} project preview`}
                    fill
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                    priority={i < 2}
                  />
                  <span className="absolute right-4 top-4 flex size-11 translate-y-2 scale-75 items-center justify-center rounded-full bg-background text-foreground opacity-0 transition-all duration-500 ease-[var(--ease-out-expo)] group-hover:translate-y-0 group-hover:scale-100 group-hover:bg-accent group-hover:opacity-100">
                    <ArrowUpRight className="size-5 transition-transform duration-500 group-hover:rotate-45" aria-hidden="true" />
                  </span>
                </div>
                <div className="mt-4 flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-2xl font-bold tracking-tight [--roll-color:var(--foreground)] [--roll-stagger:16ms]">
                      <RollText text={project.title} />
                    </h3>
                    <p className="text-sm text-muted-foreground">{project.summary}</p>
                  </div>
                  <span className="shrink-0 font-mono text-xs text-muted-foreground">
                    {String(projects.indexOf(project) + 1).padStart(2, '0')}
                  </span>
                </div>
                <ul className="mt-3 flex flex-wrap gap-1.5" aria-label="Categories">
                  {project.categories.map((c) => (
                    <li key={c} className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium">
                      {c}
                    </li>
                  ))}
                </ul>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
