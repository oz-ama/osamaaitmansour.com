import type { CSSProperties } from 'react'
import { cn } from '@/lib/utils'

type RollTextProps = {
  text: string
  className?: string
}

export function RollText({ text, className }: RollTextProps) {
  const words = text.split(' ')
  const offsets = words.map((_, w) => words.slice(0, w).reduce((sum, word) => sum + word.length, 0))

  return (
    <span className={cn('roll', className)}>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">
        {words.map((word, w) => (
          <span key={w}>
            <span className="inline-block whitespace-nowrap">
              {Array.from(word).map((char, c) => (
                <span key={c} className="roll-char" style={{ '--i': offsets[w] + c } as CSSProperties}>
                  <span>{char}</span>
                  <span>{char}</span>
                </span>
              ))}
            </span>
            {w < words.length - 1 ? ' ' : null}
          </span>
        ))}
      </span>
    </span>
  )
}
