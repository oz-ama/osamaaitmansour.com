import { ArrowUpRight } from 'lucide-react'
import { RollText } from '@/components/roll-text'

const contacts = [
  { href: 'mailto:osamaaitmansour@gmail.com', label: 'Email', value: 'osamaaitmansour@gmail.com' },
  { href: 'tel:+212636968410', label: 'Phone', value: '+212 6 36 96 84 10' },
]

export function ContactFooter() {
  return (
    <footer id="contact" aria-labelledby="contact-title" className="scroll-mt-16 bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
        <p className="font-mono text-xs uppercase tracking-widest text-ink-foreground/60">Contact</p>
        <h2
          id="contact-title"
          className="mt-2 cursor-default text-balance text-5xl font-black uppercase leading-[0.9] tracking-tighter md:text-8xl [--roll-stagger:14ms]"
        >
          <RollText text="Let's build something together" />
        </h2>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {contacts.map((contact) => (
            <a
              key={contact.href}
              href={contact.href}
              className="btn-fx flex items-center justify-between gap-4 rounded-sm border border-ink-foreground/20 p-6 [--btn-fill-foreground:var(--ink)] [--btn-fill:var(--accent)]"
            >
              <span className="min-w-0">
                <span className="block text-sm opacity-60">{contact.label}</span>
                <span className="mt-1 block break-all text-lg font-semibold md:text-2xl">{contact.value}</span>
              </span>
              <ArrowUpRight className="btn-icon size-6 shrink-0" aria-hidden="true" />
            </a>
          ))}
        </div>

        <div className="mt-20 flex flex-col gap-2 border-t border-ink-foreground/20 pt-6 text-sm text-ink-foreground/60 md:flex-row md:justify-between">
          <p>© {new Date().getFullYear()} Osama Ait Mansour</p>
          <p>Graphic Designer • UI/UX Designer • 3D Artist — Morocco</p>
        </div>
      </div>
    </footer>
  )
}
