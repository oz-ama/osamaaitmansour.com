import { RollText } from '@/components/roll-text'
import { projects } from '@/lib/projects'

const stats = [
  { value: '2016', label: 'Designing since' },
  { value: '5+', label: 'Years of professional experience' },
  { value: String(projects.length), label: 'Featured projects' },
]

const capabilities = [
  'Visual identities',
  'Catalogues & marketing collateral',
  'Photorealistic 3D renders',
  '3D characters & environments',
  'UI/UX & web experiences',
  'Social media & campaigns',
  'AI-assisted creative production',
]

const sectors = ['Furniture', 'Interior design', 'Food & beverage', 'Retail', 'Gaming', 'Digital solutions']

const education = [
  { school: 'École Supérieure des Beaux-Arts', city: 'Casablanca' },
  { school: 'Institut National des Beaux-Arts', city: 'Tétouan' },
]

export function About() {
  return (
    <section id="about" aria-labelledby="about-title" className="scroll-mt-16 border-t border-border">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-10 md:py-28">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">About</p>
            <h2 id="about-title" className="mt-2 text-balance text-4xl font-black uppercase leading-none tracking-tighter md:text-6xl">
          <RollText text="Between the real and the virtual" />
        </h2>
          </div>
          <div className="space-y-5 text-pretty leading-relaxed lg:col-span-7 md:text-lg">
            <p>
              Through visual experimentation and worldbuilding, I aim to push beyond the limits of traditional media and
              create immersive experiences that challenge the way we perceive reality.
            </p>
            <p className="text-muted-foreground">
              I specialise in creating visual identities, catalogues, marketing materials, photorealistic 3D renders and
              web experiences — and I use artificial intelligence to optimise creative processes and elevate visual
              production.
            </p>
          </div>
        </div>

        <dl className="mt-16 grid grid-cols-1 border-y border-foreground sm:grid-cols-3">
          {stats.map((s, i) => (
            <div
              key={s.label}
              className={i > 0 ? 'border-t border-border py-8 sm:border-l sm:border-t-0 sm:pl-8' : 'py-8'}
            >
              <dt className="text-sm text-muted-foreground">{s.label}</dt>
              <dd className="mt-1 text-5xl font-black tracking-tighter md:text-6xl">{s.value}</dd>
            </div>
          ))}
        </dl>

        <div className="mt-16 grid gap-12 md:grid-cols-3">
          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Capabilities</h3>
            <ul className="mt-4 space-y-2 font-medium">
              {capabilities.map((c) => (
                <li key={c} className="border-b border-border pb-2">
                  {c}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Sectors</h3>
            <ul className="mt-4 flex flex-wrap gap-2">
              {sectors.map((s) => (
                <li key={s} className="rounded-full border border-foreground px-3 py-1 text-sm font-medium">
                  {s}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Education</h3>
            <ul className="mt-4 space-y-4">
              {education.map((e) => (
                <li key={e.school}>
                  <p className="font-semibold">{e.school}</p>
                  <p className="text-sm text-muted-foreground">{e.city}, Morocco</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
