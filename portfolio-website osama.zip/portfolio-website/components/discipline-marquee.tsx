const items = ['Brand Identity', 'UI/UX Design', '3D Characters', 'Photoreal Renders', 'Campaign Design', 'Packaging', 'Social Media', 'Web Experiences']

export function DisciplineMarquee() {
  const loop = [...items, ...items]
  return (
    <div className="overflow-hidden border-y border-ink bg-ink py-5 text-ink-foreground" aria-label="Disciplines">
      <ul className="flex w-max animate-marquee items-center">
        {loop.map((item, i) => (
          <li
            key={i}
            aria-hidden={i >= items.length}
            className="flex items-center gap-8 pr-8 text-2xl font-bold uppercase tracking-tight md:text-4xl"
          >
            {item}
            <span className="size-2.5 rounded-full bg-accent" aria-hidden="true" />
          </li>
        ))}
      </ul>
    </div>
  )
}
