import Image from 'next/image'
import Link from 'next/link'
import { ArrowDownToLine, ArrowUpRight } from 'lucide-react'
import { RollText } from '@/components/roll-text'
import { HelloCycle } from '@/components/hello-cycle'

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="overflow-hidden">
      <div className="mx-auto max-w-7xl px-5 pt-10 md:px-10 md:pt-16">
        <div className="grid items-start gap-10 md:grid-cols-3">
          <div className="md:col-span-1">
            <p className="text-sm font-bold uppercase tracking-wide">Osama Ait Mansour</p>
            <p className="mt-3 max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
              Multidisciplinary designer with 5+ years of experience in graphic design, UI/UX, 3D visualisation and
              digital communication — crafting visual identities, catalogues, marketing collateral, photoreal 3D
              renders and web experiences.
            </p>
          </div>
          <div className="flex justify-start md:justify-center">
            <Image
              src="/ozama-logo.png"
              alt="Ozama signature logo"
              width={1073}
              height={1465}
              className="h-28 w-auto md:h-36"
              priority
            />
          </div>
          <div className="hidden justify-end md:flex" aria-hidden="true">
            <div className="grid grid-cols-4 gap-2">
              {Array.from({ length: 16 }).map((_, i) => (
                <span key={i} className="size-2.5 rounded-full bg-foreground" />
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-2 text-sm md:mt-24 md:flex-row md:items-end md:justify-between">
          <p className="font-medium">Graphic Designer • UI/UX Designer • 3D Artist</p>
          <div className="flex flex-wrap gap-x-10 gap-y-1 text-muted-foreground">
            <a href="tel:+212636968410" className="transition-colors hover:text-foreground">
              +212 6 36 96 84 10
            </a>
            <a href="mailto:osamaaitmansour@gmail.com" className="transition-colors hover:text-foreground">
              osamaaitmansour@gmail.com
            </a>
          </div>
        </div>
      </div>

      <h1
        id="hero-title"
        className="mt-4 cursor-default select-none text-center text-[18.5vw] font-black uppercase leading-[0.82] tracking-tighter [--roll-stagger:40ms]"
      >
        <RollText text="Portfolio" />
      </h1>

      <div className="mx-auto max-w-3xl px-5 pb-20 pt-16 text-center md:pb-28 md:pt-24">
        <HelloCycle />
        <p className="mt-8 text-pretty leading-relaxed md:text-lg">
          {"I'm Osama, a multidisciplinary artist and designer from Morocco. I bring ideas to life through graphic design, digital experiences, and 3D visualization."}
        </p>
        <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
          My practice spans design, conceptual art, art direction, and illustration. I explore the boundaries between
          the real and the virtual, combining these worlds in unconventional and unexpected ways.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a
            href="/osama-ait-mansour-cv.pdf"
            download="Osama-Ait-Mansour-CV.pdf"
            className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-3 text-sm font-semibold text-background [--btn-fill:var(--accent)] [--btn-fill-foreground:var(--foreground)]"
          >
            <ArrowDownToLine className="btn-icon size-4" aria-hidden="true" />
            Download résumé
          </a>
          <Link
            href="/resume"
            className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground px-5 py-3 text-sm font-semibold"
          >
            View résumé <ArrowUpRight className="btn-icon size-4" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </section>
  )
}
