'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { usePathname } from 'next/navigation'
import { ArrowDownToLine, ArrowUpRight, X } from 'lucide-react'

const ENTRY_DELAY_MS = 2000 // first visit: show 2s after arriving
const NAV_DELAY_MS = 1500 // after moving to another page
const STAY_DELAY_MS = 60_000 // still on the site: show again after a minute
const MIN_GAP_MS = 15_000 // don't re-open a page-change popup right after it was closed

export function WelcomePopup() {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const [open, setOpen] = useState(false)
  const mountedRef = useRef(false)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const lastClosed = useRef(0)
  const prevPath = useRef(pathname)
  const cardRef = useRef<HTMLDivElement>(null)
  const lastFocused = useRef<HTMLElement | null>(null)

  const openPopup = useCallback(() => {
    if (mountedRef.current) return
    mountedRef.current = true
    lastFocused.current = document.activeElement as HTMLElement | null
    setMounted(true)
    requestAnimationFrame(() => requestAnimationFrame(() => setOpen(true)))
  }, [])

  const schedule = useCallback(
    (ms: number) => {
      if (timer.current) clearTimeout(timer.current)
      timer.current = setTimeout(openPopup, ms)
    },
    [openPopup],
  )

  const close = useCallback(() => {
    setOpen(false)
    lastClosed.current = Date.now()
    setTimeout(() => {
      setMounted(false)
      mountedRef.current = false
    }, 350)
    lastFocused.current?.focus?.({ preventScroll: true })
    schedule(STAY_DELAY_MS) // if they're still around in a minute, show it again
  }, [schedule])

  // 1) On arrival
  useEffect(() => {
    schedule(ENTRY_DELAY_MS)
    return () => {
      if (timer.current) clearTimeout(timer.current)
    }
  }, [schedule])

  // 2) When the visitor moves to another page (always when going back to the homepage)
  useEffect(() => {
    if (prevPath.current === pathname) return
    prevPath.current = pathname
    const onHomepage = pathname === '/'
    // Coming back to a plain homepage always shows it. A link like /#contact (e.g. "Get in touch") doesn't.
    if (onHomepage && window.location.hash) return
    if (onHomepage || Date.now() - lastClosed.current > MIN_GAP_MS) schedule(NAV_DELAY_MS)
  }, [pathname, schedule])

  // Lock page scroll, focus the first button, handle Escape + focus trap.
  useEffect(() => {
    if (!open) return
    const prev = document.documentElement.style.overflow
    document.documentElement.style.overflow = 'hidden'
    cardRef.current?.querySelector<HTMLElement>('a, button')?.focus({ preventScroll: true })
    cardRef.current?.querySelector<HTMLElement>('[data-first]')?.focus({ preventScroll: true })

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') return close()
      if (e.key !== 'Tab' || !cardRef.current) return
      const els = cardRef.current.querySelectorAll<HTMLElement>('a, button')
      const first = els[0]
      const last = els[els.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      document.documentElement.style.overflow = prev
      document.removeEventListener('keydown', onKey)
    }
  }, [open, close])

  if (!mounted) return null

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="welcome-title"
      className={`fixed inset-0 z-[100] grid place-items-center p-5 transition-opacity duration-300 ${open ? 'opacity-100' : 'opacity-0'}`}
    >
      <div className="absolute inset-0 bg-ink/55 backdrop-blur-sm" onClick={close} aria-hidden="true" />
      <div
        ref={cardRef}
        className={`relative w-full max-w-lg rounded-lg border border-foreground bg-card p-7 pt-9 shadow-2xl transition-transform duration-700 ease-[var(--ease-out-expo)] md:p-9 ${open ? 'translate-y-0 scale-100' : 'translate-y-10 scale-95'}`}
      >
        <button
          type="button"
          onClick={close}
          aria-label="Close"
          className="absolute right-3 top-3 grid size-9 place-items-center rounded-full transition-all duration-500 ease-[var(--ease-out-expo)] hover:rotate-90 hover:bg-secondary"
        >
          <X className="size-5" aria-hidden="true" />
        </button>

        <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          <span className="size-2 animate-pulse rounded-full bg-emerald-600" aria-hidden="true" />
          Open for new projects
        </span>

        <h2
          id="welcome-title"
          className="mt-4 text-5xl font-black uppercase leading-[0.92] tracking-[-0.05em] md:text-6xl"
        >
          Let’s work
          <br />
          together<span className="text-accent">.</span>
        </h2>

        <p className="mt-4 text-pretty text-[15px] leading-relaxed text-muted-foreground">
          Got a brand, a website or a 3D idea that needs to look unforgettable? Grab my CV or tell me what you’re
          building.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <a
            data-first
            href="/osama-ait-mansour-cv.pdf"
            download="Osama-Ait-Mansour-CV.pdf"
            onClick={close}
            className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground bg-foreground px-5 py-3 text-sm font-semibold text-background [--btn-fill:var(--accent)] [--btn-fill-foreground:var(--foreground)]"
          >
            <ArrowDownToLine className="btn-icon size-4" aria-hidden="true" />
            Download CV
          </a>
          <a
            href="/#contact"
            onClick={close}
            className="btn-fx inline-flex items-center gap-2 rounded-full border border-foreground px-5 py-3 text-sm font-semibold"
          >
            Get in touch <ArrowUpRight className="btn-icon size-4" aria-hidden="true" />
          </a>
        </div>

        <button
          type="button"
          onClick={close}
          className="mt-5 text-[13px] text-muted-foreground underline underline-offset-4 transition-colors hover:text-foreground"
        >
          Maybe later
        </button>
      </div>
    </div>
  )
}
