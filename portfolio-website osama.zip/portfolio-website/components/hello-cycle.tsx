'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

const greetings = [
  { text: 'Hello', lang: 'en' },
  { text: 'سلام', lang: 'ar' },
  { text: 'Bonjour', lang: 'fr' },
  { text: '你好', lang: 'zh' },
]

const INTERVAL_MS = 1100

export function HelloCycle() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const id = setInterval(() => setIndex((i) => (i + 1) % greetings.length), INTERVAL_MS)
    return () => clearInterval(id)
  }, [])

  const n = greetings.length

  return (
    <div className="mx-auto grid cursor-default select-none place-items-center overflow-hidden px-3 py-1 text-5xl leading-[1.3] md:text-6xl">
      <span className="sr-only">Hello</span>
      {greetings.map((g, i) => {
        const state = i === index ? 'active' : i === (index + n - 1) % n ? 'prev' : 'next'
        return (
          <span
            key={g.lang}
            lang={g.lang}
            dir={g.lang === 'ar' ? 'rtl' : undefined}
            aria-hidden="true"
            className={cn(
              'col-start-1 row-start-1 whitespace-nowrap font-extrabold uppercase tracking-tight',
              'transition-[transform,opacity,filter] duration-500 ease-[var(--ease-out-expo)] motion-reduce:transition-opacity',
              g.lang === 'ar' && 'font-[family-name:var(--font-arabic)] font-medium normal-case tracking-normal',
              g.lang === 'zh' && "font-extrabold tracking-[0.06em] [font-family:'PingFang_SC','Microsoft_YaHei','Noto_Sans_CJK_SC',sans-serif]",
              state === 'active' && 'translate-y-0 rotate-0 opacity-100 blur-none',
              state === 'prev' && '-translate-y-3/4 -rotate-3 opacity-0 blur-[3px]',
              state === 'next' && 'translate-y-3/4 rotate-3 opacity-0 blur-[3px]',
            )}
          >
            {g.text}
          </span>
        )
      })}
    </div>
  )
}
