# Osama Ait Mansour — Portfolio

    npm install
    npm run dev      # http://localhost:3000
    npm run build    # production build

